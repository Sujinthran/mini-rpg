import javax.swing.JPanel;

public class Board extends JPanel {

    public Board() {}
}