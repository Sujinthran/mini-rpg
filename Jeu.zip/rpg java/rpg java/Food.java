public class Food implements Consomable{

}

class pain extends Food{

}

class viande extends Food {

}

class pomme extends Food {
        
}

class voide extends Food {

}