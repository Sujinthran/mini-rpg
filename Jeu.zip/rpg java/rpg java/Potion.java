public class Potion implements Consomable {
}

class potionMana extends Potion {
}

class potionVie extends Potion{

}

class vide extends Potion {

}